
1. python -m classification.export_training_data
2. python -m classification.tokenize
3. python -m classification.create_partitions
4. python -m classification.run
5. python -m classification.do_prediction --dataset icml
6. python -m classification.do_prediction --dataset neurips
5. python -m classification.make_plots