
This directory contains work-in-progress script to download ICML papers
Because it is only a partial attempt, it depends on manually copied links from the ICML websites.
This should eventually be automated.

In the meantime, this should allow one to obtain all of the pdfs for papers at ICML main conferences (2009-2020)

Note that the pdfs from 2008 can be downloaded as a zipfile from the conference website

1. download_pdfs.py
2. convert_pdfs_to_text.py
3. parse_papers.py